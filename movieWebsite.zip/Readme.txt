
The creator of this program is Siddarth Krishnan

It was created on August 6 2017


This is a program where you run the entertainment_center.py and it shows a list of movies on a site with their respective images. Click on the individual images to view the individual trailers.