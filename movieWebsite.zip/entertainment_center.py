import fresh_tomatoes
import media

toy_storie = media.Movie("ToyStory", "A story of his boy and his toy", "http://a.dilcdn.com/bl/wp-content/uploads/sites/8/2013/02/toy_story_wallpaper_by_artifypics-d5gss19.jpg", "https://www.youtube.com/watch?v=KYz2wyBy3kc")
print(toy_storie.storyline) #uses init to create an instance of a Movie object

avatar = media.Movie("Avatar", "A story of an marine on an alient planet", "https://images-na.ssl-images-amazon.com/images/M/MV5BMTYwOTEwNjAzMl5BMl5BanBnXkFtZTcwODc5MTUwMw@@._V1_UY1200_CR90,0,630,1200_AL_.jpg","https://www.youtube.com/watch?v=d1_JBMrrYw8")
print(avatar.storyline)

inception = media.Movie("Inception", "A story of distoerted reality", "https://www.warnerbros.com/sites/default/files/styles/key_art_270x400/public/inception_keyart.jpg?itok=7jXiglyb", "https://www.youtube.com/watch?v=YoHD9XEInc0")

lionKing = media.Movie("Lion King", "A story lions", "http://thumbs4.ebaystatic.com/d/l225/m/m0cUhs3_IBZSIGIXrUHyW3Q.jpg", "https://www.youtube.com/watch?v=zx3LT_G3cIA")


avatar.show_trailer()#calls the show trailer method 


movieList = [toy_storie, avatar, inception, lionKing] # stores the movies in an array
fresh_tomatoes.open_movies_page(movieList)# uses the function to make an html page of the movies list
